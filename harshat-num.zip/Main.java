import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int sum=0;
		int num=n;
		int rem;
		while(n>0)
		{
		    rem=n%10;
		    sum=sum+rem;
		    
		    n=n/10;
		}
		if((num%sum)==0)
		{
		    System.out.println("Yes");
		}
		else{
		    System.out.println("No");
		}
	}
}
