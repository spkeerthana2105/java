import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=1729;
		int a;
		
		int mul;
		int num;
		a=n;
		int sum=0,rev=0;
		int rem;
		int d=num;
		while(n>0)
		{
	      rem=n%10;
	      sum=sum+rem;
	      n=n/10;
		}
		while(sum>0)
		{
		    rem=sum%10;
		    rev=(rev*10)+rem;
		    sum=sum/10;
		}
		mul=rev*d;
	if(a==mul)
	{
	    System.out.println("Yes");
	}
	else{
	    System.out.println("No");
	}
	    }
	}