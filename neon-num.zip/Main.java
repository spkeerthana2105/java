import java.util.*;
public class Main
{
	public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int sq=n*n;
        int sum=0;
        int rem;
        while(sq>0)
{
     rem=sq%10;
     sum=sum+rem;
     sq=sq/10;
}
        if(sum==n)
        {
            System.out.println("yes");
        }
        else{
            System.out.println("No");
        }
	}
}
